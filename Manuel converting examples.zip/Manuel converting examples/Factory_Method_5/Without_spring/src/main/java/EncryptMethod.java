public enum EncryptMethod {
    REVERSE,
    REVERSE_SKIP_FIRST,
    SWITCH_FIRST_LAST
}
