public interface Encryptors {
    int[] encrypt(int[] arr);
}
