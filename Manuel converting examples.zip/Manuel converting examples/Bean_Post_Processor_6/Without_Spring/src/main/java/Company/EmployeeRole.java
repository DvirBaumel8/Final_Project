package Company;

public enum EmployeeRole {
    DEVELOPER,
    TEAM_LEADER,
    HR,
    QUALITY_INSURANCE,
    PRODUCT_MANAGER
}
