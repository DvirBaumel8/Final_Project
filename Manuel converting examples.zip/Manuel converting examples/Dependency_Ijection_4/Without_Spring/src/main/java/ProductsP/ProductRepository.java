package ProductsP;

import java.util.List;

public interface ProductRepository {
    List<Product> getAllProducts();
}
