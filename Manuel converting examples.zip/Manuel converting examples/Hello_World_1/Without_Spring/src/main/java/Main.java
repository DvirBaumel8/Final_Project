public class Main {
    public static void main(String[] args) {
        HelloWorld helloWorld = new HelloWorld();
        helloWorld.setMessage("Hello world first example");
        String message = helloWorld.getMessage();
        System.out.println(message);
    }
}
